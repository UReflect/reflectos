<template>
    <!--HTML goes in here-->
    <div id="page" class="spotify-module">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
              integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm"
              crossorigin="anonymous">
        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
        <div class="widget" data-posX="2" data-posY="8" data-x="4" data-y="2">
            <div id="wrapper">
                <div class="container">
                    <div class="row">
                        <img style="width: 50px;height: 50px;margin-right: 10px" src="~@/assets/Spotify.png"/>
                        <div class="col-md-6">
                            <div class="buttonInside">
                                <input v-model="message" class="inputSearch" placeholder="Type a song...">
                                <button id="erase" @click="search()"><img class="iconSearch"
                                                                          src="~@/assets/searchicon.png"/></button>
                            </div>
                            <div id="test">
                                <ul>
                                    <li class="w3-ul" v-for="track in tracks_display" :key="track.id" @click="play(track.uri)"
                                        > {{track.name}}
                                    </li>
                                </ul>
                            </div>
                            <div class="player-controls__buttons">
                                <button @click="shuffleTrack(shuffleState)" class="control-button spoticon-shuffle-16"
                                        title="Activer la lecture aléatoire" v-if="!shuffleState"></button>
                                <button @click="shuffleTrack(shuffleState)"
                                        class="control-button spoticon-shuffle-16 control-button--active control-button--active-dot"
                                        title="Disable shuffle" v-if="shuffleState"></button>
                                <button @click="prevTrack()" class="control-button spoticon-skip-back-16"
                                        title="Précédent"></button>
                                <button @click="pause()"
                                        class="control-button spoticon-pause-16 control-button--circled" title="Pause"
                                        v-if="playBool"></button>
                                <button @click="resume()"
                                        class="control-button spoticon-play-16 control-button--circled" title="Lecture"
                                        v-if="!playBool"></button>
                                <button @click="nextTrack()" class="control-button spoticon-skip-forward-16"
                                        title="Suivant"></button>
                                <button @click="repeatTrack(repeatState)" class="control-button spoticon-repeat-16"
                                        title="Activer la répétition" v-if="!repeatState"></button>
                                <button @click="repeatTrack(repeatState)"
                                        class="control-button spoticon-repeat-16 control-button--active control-button--active-dot"
                                        title="Enable repeat one" v-if="repeatState"></button>
                                <!--<p>Current Track playing: <div id="currentTrack"> {{ this.currentTrack }} </div></p>-->
                            </div>
                        </div>
                        <div class="col-md-6">

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>


<script>
  import Vue from 'vue'

  const widevine = require('electron-widevinecdm');

  export default {
    name: 'Spotify',
    data() {
      return {
        message: '',
        tracks: {},
        tracks_display: {},
        toto2: false,
        toto: '',
        playBool: false,
        shuffleState: false,
        repeatState: false,
        currentTrack: '',
      }
    },

    methods: {
      search: function () {
        this.$httpSpotify.search(this.message, 'track').then(res => {
          console.log('toto');
          this.tracks = res.data.tracks.items;
          var arr = {};
          var size = Object.keys(this.tracks).length;
          var i = 0;
          for (i = 0; i < size && i < 4; i++) {
            arr[i] = this.tracks[i];
          }
          this.tracks_display = arr;
          console.log(this.tracks);
          console.log(this.tracks_display);
          console.log(res);
          this.message = '';
        }).catch(err => {
          console.log('tata');
          console.error(err);
        })
      },

      play: function(uri) {
        var size = Object.keys(this.tracks).length;
        var tracks = new Array(0);
        var i = 0;

        for (i = 0; i < size; i++) {
          console.log(this.tracks[5]);
          if (this.tracks[i].uri === uri) {
            tracks.unshift(this.tracks[i].uri);
          }
          else {
            tracks.push(this.tracks[i].uri);
          }
          this.playBool = true;
        }
        this.tracks_display = '';
        Vue.prototype.$httpSpotify.play(tracks).then(function () {
        }).catch(err => {
          console.error(err);
        })
      },

      resume: function() {
        Vue.prototype.$httpSpotify.resume().then(() => {
          this.playBool = true;
        }).catch(err => {
          console.error(err);
        })
      },

      pause: function() {
        Vue.prototype.$httpSpotify.pause().then( () => {
          this.playBool = false;
        }).catch(err => {
          console.error(err);
        })
      },

      prevTrack: function() {
        Vue.prototype.$httpSpotify.prevTrack().then( () => {
          this.playBool = true;
        }).catch(err => {
          console.error(err);
        })
      },

      nextTrack: function() {
        Vue.prototype.$httpSpotify.nextTrack().then(() =>{
          this.playBool = true;
        }).catch(err => {
          console.error(err);
        })
      },

      getCurrentTrack() {
        if (this.message !== '') {
          Vue.prototype.$httpSpotify.getCurrentTrack().then(function () {
          }).catch(err => {
            console.error(err);
          })
        }
      },

      repeatTrack() {
        this.repeatState = !this.repeatState
        Vue.prototype.$httpSpotify.repeatTrack(this.repeatState).then(function () {
        }).catch(err => {
          console.error(err);
        })
      },

      shuffleTrack() {
        this.shuffleState = !this.shuffleState;
        Vue.prototype.$httpSpotify.shuffleTrack(this.shuffleState).then(function () {
          console.log(this.shuffleState);
        }).catch(err => {
          console.error(err);
        })
      }
    },
    mounted: function() {
      let playerScript = document.createElement("script");
      this.$httpSpotify.setBearer('BQDEpduJhMDYHPmyXF8x7pyTzggIN_pJybNqTE8BrciPbi3CtjCeGAiG54yFnCjB2We6Y9qnFvZI81SCBgex6OppYOHpGMYIJ7QiJHF-S-9dkj4kL0EGOi_1vViPaIPVnwaMcueRRqVpHSqDFW3NYgLJQicbwHYEdVjRf-A3zGQ');
      playerScript.appendChild(document.createTextNode("window.onSpotifyWebPlaybackSDKReady = () => {\n" +
        "            const token = 'BQDEpduJhMDYHPmyXF8x7pyTzggIN_pJybNqTE8BrciPbi3CtjCeGAiG54yFnCjB2We6Y9qnFvZI81SCBgex6OppYOHpGMYIJ7QiJHF-S-9dkj4kL0EGOi_1vViPaIPVnwaMcueRRqVpHSqDFW3NYgLJQicbwHYEdVjRf-A3zGQ';\n" +
        "            const player = new Spotify.Player({\n" +
        "                name: 'uReflect',\n" +
        "                getOAuthToken: cb => { cb(token); }\n" +
        "            });\n" +
        "\n" +
        "            // Error handling\n" +
        "            player.on('initialization_error', e => { console.error(e); });\n" +
        "            player.on('authentication_error', e => { console.error(e); });\n" +
        "            player.on('account_error', e => { console.error(e); });\n" +
        "            player.on('playback_error', e => { console.error(e); });\n" +
        "\n" +
        "            // Playback status updates\n" +
        "            player.on('player_state_changed', state => { console.log(state); });\n" +
        "\n" +
        "            // Ready\n" +
        "            player.on('ready', data => {\n" +
        "                let { device_id } = data;\n" +
        "                console.log('Ready with Device ID', device_id);\n" +
        "            });\n" +
        "\n" +
        "            // Connect to the player!\n" +
        "            player.connect();\n" +
        "        }\n"));

      let sdkSpotifyConnectScript = document.createElement('script');
      sdkSpotifyConnectScript.setAttribute('src', 'https://sdk.scdn.co/spotify-player.js');
      document.head.appendChild(playerScript);
      document.head.appendChild(sdkSpotifyConnectScript);
    }
  }
</script>

<style scoped>
    /* CSS goes in here */
    @import url('https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900');

    .spotify-module * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
    }

    #page-component {
        width: 100vw;
        height: 100vh;
        display: block;
    }

    #wrapper {
        background-color: rgba(21, 21, 28, 1);
    }

    #logo {
        height: auto;
        width: 420px;
        margin: auto;
        animation-duration: 4s;
        animation-name: fade;
        animation-timing-function: ease-in;
    }

    main.landing {
        display: flex;
        justify-content: space-between;
        height: 100%;
        animation-name: pulse;
        animation-duration: 2s;
        animation-delay: 2s;
        animation-timing-function: ease-in-out;
        animation-iteration-count: infinite;
        vertical-align: middle;
    }

    .loader {
        display: table;
        margin: auto auto;
        height: 50px;
    }

    .loader > h3 {
        display: table-cell;
        text-align: center;
        font-size: 23px;
        font-weight: 100;
        color: #fff;
        opacity: 0;
        animation-name: flash;
        animation-duration: 2s;
        animation-timing-function: ease-in-out;
        vertical-align: middle;
    }

    .spotify-module input[type=text] {
        width: 130px;
        -webkit-transition: width 0.4s ease-in-out;
        transition: width 0.4s ease-in-out;
    }

    .spotify-module p {
        margin-left: 10px;
        color: white;
    }

    @font-face {
        font-family: glue1-spoticon;
        src: url('~@/assets/spoticon_regular_2.woff2');
    }

    .player-controls__buttons {
        margin-bottom: 12px;
        display: -ms-flexbox;
        display: flex;
        -ms-flex-pack: justify;
        justify-content: space-between;
        -ms-flex-flow: row nowrap;
        flex-flow: row nowrap;
    }

    .control-button {
        background-color: transparent;
        border: none;
        color: hsla(0, 0%, 100%, .6);
        width: 32px;
        min-width: 32px;
        height: 32px;
        position: relative;
    }

    .spoticon-shuffle-16:before {
        content: "\F144";
        font-size: 16px;
    }

    .spoticon-shuffle-16:before {
        content: "\F144";
        font-size: 16px;
    }

    .spoticon-skip-back-16:before {
        content: "\F146";
        font-size: 16px;
    }

    .spoticon-skip-back-16:before {
        content: "\F146";
        font-size: 16px;
    }

    .spoticon-play-16:before {
        content: "\F132";
        font-size: 16px;
    }

    .spoticon-play-16:before {
        content: "\F132";
        font-size: 16px;
    }

    .control-button--circled:after {
        content: "";
        position: absolute;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        border-radius: 500px;
        border: 1px solid hsla(0, 0%, 100%, .6);
    }

    .spoticon-skip-forward-16:before {
        content: "\F148";
        font-size: 16px;
    }

    .spoticon-skip-forward-16:before {
        content: "\F148";
        font-size: 16px;
    }

    .spoticon-repeat-16:before {
        content: "\F13E";
        font-size: 16px;
    }

    [class*=" spoticon-"]:before, [class^=spoticon-]:before {
        font-family: glue1-spoticon;
        font-style: normal;
        font-weight: 400;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
        line-height: inherit;
        vertical-align: bottom;
        display: inline-block;
        text-decoration: inherit;
    }

    .spoticon-repeat-16:before {
        content: "\F13E";
        font-size: 16px;
    }

    .spoticon-pause-16:before {
        content: "\F130";
        font-size: 16px;
    }

    [class*=" spoticon-"]:before, [class^=spoticon-]:before {
        font-family: glue1-spoticon;
        font-style: normal;
        font-weight: 400;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
        line-height: inherit;
        vertical-align: bottom;
        display: inline-block;
        text-decoration: inherit;
    }

    .spotify-module .spoticon-pause-16:before {
        content: "\F130";
        font-size: 16px;
    }

    .spotify-module .control-button--active {
        color: #1db954;
    }

    .spotify-module .buttonInside {
        position: relative;
        width: 225px;
        margin-bottom: 10px;
    }

    .spotify-module .inputSearch {
        border-radius: 20px;
        background-color: #FFFFFF;
        font-family: inherit;
        border-style: solid;
        border-width: 1px;
        border-color: #cccccc;
        box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1);
        color: rgba(0, 0, 0, 0.75);
        display: block;
        font-size: 0.875rem;
        margin: 0 0 1rem 0;
        padding: 0.5rem;
        height: 2.3125rem;
        width: 100%;
    }

    .spotify-module .iconSearch {
        width: 20px;
        height: 20px;
        margin-right: 10px;
        margin-bottom: 3px;
    }

    .player-controls__buttons {
        width: 100%;
        justify-content: space-between;
    }

    .spotify-module #erase {
        position: absolute;
    }

    .spotify-module button {
        border-radius: 50px;
        right: 0px;
        top: 4px;
        border: none;
        height: 30px;
        width: 30px;
        outline: none;
        text-align: center;
        font-weight: bold;
        padding: 2px;
    }

    .spotify-module button:hover {
        cursor: pointer;
    }

    .spotify-module .widget {
        float: left;
    }

</style>
